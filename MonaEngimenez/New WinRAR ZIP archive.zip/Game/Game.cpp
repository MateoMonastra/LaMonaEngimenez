#pragma once

#include "Game.h"  
#include "Window\Window.h"
#include "glm.hpp"


static float FlashingColor()
{
	static float increment = 0.005f;
	static float color = 0.0f;

	if (color > 1.0f || color < 0.0f)
	{
		increment = -increment;
	}

	return color += increment;
}

Game::Game(float width, float height)
	: BaseGame(width, height)
{
	Init();
}

Game::~Game()
{
	Deinit();
}

void Game::Init()
{  
   texture = new Texture("../Assets/Milhouse.png");

   texture->SetTranslation(texture->GetWidth() / 2.0f, (screenHeight - texture->GetHeight() / 2.0f));
}  

void Game::Update()  
{  
	texture->Draw(0.1f);
}  

void Game::Deinit()  
{  
	delete texture;
}
