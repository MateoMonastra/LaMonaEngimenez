#pragma once

#include "Exporter.h"

MONA_ENGIMENEZ class Entity
{
public:

	 virtual void Draw() = 0;
};

