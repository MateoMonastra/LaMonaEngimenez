#pragma once
#include "Exporter.h"

#include "Entity/Entity2D/Shape/Shape.h"
//#include "BufferLayout/BufferLayout.h"


class MONA_ENGIMENEZ Triangle : public Shape
{
public:

	Triangle(float width, float height);
	~Triangle();
};

